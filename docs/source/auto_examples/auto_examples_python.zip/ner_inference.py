"""
Inferens på NER model
===============================

This is docstring
"""
